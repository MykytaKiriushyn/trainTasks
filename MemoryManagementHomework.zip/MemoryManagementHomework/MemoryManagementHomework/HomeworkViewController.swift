//
//  HomeworkViewController.swift
//  MemoryManagementHomework
//
//  Created by Dmytro Kolesnyk2 on 14.05.2020.
//  Copyright © 2020 Dmytro Kolesnyk. All rights reserved.
//

import UIKit

class HomeworkViewController: UIViewController {
    enum Const {
        static let title = "Homework"
        static let cellReuseIdentifier = "HomeworkCellReuseIdentifier"
        static let url = "https://picsum.photos/200/300"
    }
    private var tableView = UITableView(frame: .zero, style: .grouped)
    private var pictures: [UIImage] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupSubview()
        setupAutoLayout()
        setupPictures()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func changePictures() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            
            self?.pictures.removeAll()
            
            guard let url = URL(string: Const.url) else { return }
            
            for _ in 0..<10 {
                guard let image = UIImage(url: url) else { continue }
                self?.pictures.append(image)
            }
            
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }
}

// MARK: - Private
private extension HomeworkViewController {
   func setupSubview() {
        title = Const.title
        tableView.register(HomeworkCell.self, forCellReuseIdentifier: Const.cellReuseIdentifier)
        view.addSubview(tableView)
    }
    
    func setupAutoLayout() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }

    func setupPictures() {
        for i in 1...10 {
            guard let image = UIImage(named: "picture\(i)") else { continue }
            pictures.append(image)
        }
    }
    
    func setupTransition(from indexPath: IndexPath) {
        let viewController = DetailsViewController(model: DetailsViewControllerModel(image: pictures[indexPath.row],
                                                                                     text: randomString(length: 1200)),
                                                   output: self)
        
        navigationController?.present(viewController, animated: true)
    }
    
    func randomString(length: Int) -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<length).map{ _ in (letters.randomElement() ?? " ") })
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension HomeworkViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pictures.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Const.cellReuseIdentifier,
                                                 for: indexPath) as? HomeworkCell
        
        cell?.homeworkImage = pictures[indexPath.row]
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let ratio = pictures[indexPath.row].getImageRatio()
        return tableView.frame.width / ratio
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        setupTransition(from: indexPath)
    }
}

extension HomeworkViewController {
    func callAlert() {
        let alert = UIAlertController(title: "Please", message: "Kill or fix me", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: .none))
        alert.addAction(UIAlertAction(title: "NO", style: .destructive, handler: { action in
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                exit(0)
            }
        }))
        DispatchQueue.main.async { [weak self] in
            self?.present(alert, animated: true)
        }
    }
}
    
// MARK: - DetailsViewControllerOutput
extension HomeworkViewController: DetailsViewControllerOutput {
    func didLoad() {
        changePictures()
    }
    
    func didDisappear() {
        callAlert()
    }
}
