//
//  DetailsViewController.swift
//  MemoryManagementHomework
//
//  Created by Dmytro Kolesnyk2 on 14.05.2020.
//  Copyright © 2020 Dmytro Kolesnyk. All rights reserved.
//

import UIKit

struct DetailsViewControllerModel {
    let image: UIImage
    let text: String
}

protocol DetailsViewControllerOutput: class {
    func didLoad()
    func didDisappear()
}

class DetailsViewController: UIViewController {
    private let model: DetailsViewControllerModel
    private weak var output: DetailsViewControllerOutput?
    
    private lazy var imageView = UIImageView()
    private lazy var textLabel = UILabel()
    private lazy var stackView = UIStackView()
    
    init(model: DetailsViewControllerModel, output: DetailsViewControllerOutput) {
        self.model = model
        self.output = output
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupSubviews()
        setupAutoLayout()
        output?.didLoad()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        output?.didDisappear()
    }
    
    func setupSubviews() {
        view.addSubview(stackView)
        stackView.addSubview(imageView)
        stackView.addSubview(textLabel)
        
        view.backgroundColor = .white
        imageView.image = model.image
        textLabel.numberOfLines = 0
        textLabel.text = model.text
    }
    
    func setupAutoLayout() {
        stackView.translatesAutoresizingMaskIntoConstraints = false
        imageView.translatesAutoresizingMaskIntoConstraints = false
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        let height = view.frame.width / model.image.getImageRatio()
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
            textLabel.leadingAnchor.constraint(equalTo: stackView.leadingAnchor),
            textLabel.trailingAnchor.constraint(equalTo: stackView.trailingAnchor),
            textLabel.heightAnchor.constraint(lessThanOrEqualToConstant: 150),
            textLabel.bottomAnchor.constraint(equalTo: stackView.bottomAnchor),
            
            imageView.leadingAnchor.constraint(equalTo: stackView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: stackView.trailingAnchor),
            imageView.heightAnchor.constraint(equalToConstant: height),
            imageView.topAnchor.constraint(equalTo: stackView.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: textLabel.topAnchor)
        ])
    }
}
