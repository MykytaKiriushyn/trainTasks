import UIKit

typealias Matrix = [[Int]]

func createMatrix(range: Int) -> Matrix {
    var matrix = Matrix()
    let lineSize = Int(sqrt(Double(range)))
    for _ in 0...lineSize {
        var array = [Int]()
        for _ in 0...lineSize {
            array.append(Int.random(in: 0...range))
        }
        matrix.append(array)
    }
    return matrix
}

func multiplyMatrix(firstMatrix: Matrix, secondMatrix: Matrix) -> Matrix? {
    var resultMatrix = Matrix()
    let firstMatrixRows = firstMatrix.count
    guard let secondMatrixColumns = secondMatrix.first?.count else { return nil }
    
    if firstMatrixRows == secondMatrixColumns {
        
        for i in 0..<firstMatrixRows {
            var array = [Int]()
            for j in 0..<secondMatrixColumns{
                var sum = 0
                for k in 0..<firstMatrixRows {
                    sum += firstMatrix[i][k] * secondMatrix[k][j];
                }
                array.append(sum)
            }
            resultMatrix.append(array)
        }
    }
    return resultMatrix
}

var group = DispatchGroup()
var firstMatrix = Matrix()
var secondMatrix = Matrix()
let range = 10000

let startTime = Date()

//DispatchQueue.global(qos: .utility).async(group: group, execute: {
    firstMatrix = createMatrix(range: range)
//})

//DispatchQueue.global(qos: .utility).async(group: group, execute: {
    secondMatrix = createMatrix(range: range)
//})

//group.notify(queue: DispatchQueue.main) {
    if let resultMatrix = multiplyMatrix(firstMatrix: firstMatrix,
                                         secondMatrix: secondMatrix) {
        let time = Date().distance(to: startTime)
        print(time.description)
      } else {
          print("GG")
      }
//}

// GCD -44.69748604297638
// just -49.47748506069183
